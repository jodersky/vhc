Virtual Hadron Collider
========================

Projet d'informatique 2011
Jakob Odersky, Christian Vazquez

1. Nous avons tout fait jusqu'au parseurs. Concernant les interactions particules, nous avons implementes notre propre methode.
2. Nous utilisons Qt pour l'interface graphique.
3. En moyenne nous avons passe 4 heures par semaine sur le projet

========================
Prerequis:
========================

Qt pour l'interface graphique
Doxygen pour generer la documentation
GraphVIZ/Dot pour des jolies schemas dans la documentation

========================
Compilation:
========================

commande: effet

make doc: genere la documentation (doc/html/index.html)
make build: compile le programme
make test: lance les tests
make gui lance l'interface graphique

========================
Interface graphique:
========================
navigation: touches w,a,s,d pour bouger, souris pour changer tourner

clique gauche: capturer/lacher la souris

1: vue pleine
2: vue grille
3: vue points
0: afficher points/spheres pour particules

REMARQUE: nous avons constate des problemes avec le rendement graphique en salles CO. Ses probleme ne se manifestent que sur les machines virtuelles.

