//ce fichier ne contient que la documentation de l'espace de nom

/** Espace de nom contenant tout code relatif au projet `Virtual Hadron Collider'. */
namespace vhc {};
