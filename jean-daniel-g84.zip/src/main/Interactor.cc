/*
 * Interactor.cc
 *
 *  Created on: May 26, 2011
 *      Author: jakob
 */

#include "Interactor.h"
#include "Accelerator.h"

namespace vhc {

Interactor::Interactor() {}

Interactor::~Interactor() {}

//rien par defaut
void Interactor::acceleratorClosed(const Accelerator& acc) {}

}
