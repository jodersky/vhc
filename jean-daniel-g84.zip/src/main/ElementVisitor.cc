/*
 * ElementVisitor.cc
 *
 *  Created on: Apr 2, 2011
 *      Author: jakob
 */

#include "ElementVisitor.h"

namespace vhc {

ElementVisitor::ElementVisitor() {}

ElementVisitor::~ElementVisitor() {}

}
