/*
 * Cloneable.cc
 *
 *  Created on: Apr 12, 2011
 *      Author: jakob
 */

#include "Cloneable.h"

namespace vhc {

Cloneable::Cloneable() {

}

Cloneable::~Cloneable() {
}

}
