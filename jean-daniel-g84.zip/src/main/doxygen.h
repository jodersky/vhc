/*
 * doxygen.h
 *
 *  Created on: Apr 17, 2011
 *      Author: jakob
 */

#ifndef DOXYGEN_H_

/**@mainpage
 *
 */




#define DOXYGEN_H_


#endif /* DOXYGEN_H_ */
